<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>svg_Post_MuiSvgIcon-root MuiSvgIcon-fontSiz_2ed3f8</name>
   <tag></tag>
   <elementGuidId>81ebc1da-cd40-46bb-97c3-4beb6d1b909e</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>/html/body/div/div/div/div[1]/div[2]/ul/li[4]</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>(.//*[normalize-space(text()) and normalize-space(.)='Post'])[1]/following::*[name()='svg'][1]</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value></value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html/body/div/div/div/div[1]/div[2]/ul/li[4]</value>
      <webElementGuid>1ef46678-a6bd-4ce9-a49e-1435adc7da35</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Post'])[1]/following::*[name()='svg'][1]</value>
      <webElementGuid>c1845fac-6e1c-4526-8052-94f55db025f3</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Users'])[1]/following::*[name()='svg'][2]</value>
      <webElementGuid>5a6b2d72-05d7-4a1e-92f3-a18ea9d833a6</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Topic'])[1]/preceding::*[name()='svg'][1]</value>
      <webElementGuid>48bfb52a-a30f-407b-af86-844f5655ea4f</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Log out'])[1]/preceding::*[name()='svg'][2]</value>
      <webElementGuid>3b3f1e26-18a1-4aa1-ab8b-b4dff67671ce</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
