<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>svg_Technology is a technology best_MuiSvgI_a4e357</name>
   <tag></tag>
   <elementGuidId>73dba331-3312-4974-96b1-acc06d7e3fd5</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>/html/body/div/div/div/div[2]/div/div/div/div/div/div[2]/div[2]/div/div/div/div[1]/div[4]/div/button[1]</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>(.//*[normalize-space(text()) and normalize-space(.)='Technology is a technology best'])[1]/following::*[name()='svg'][1]</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>button.bg-danger.p-2.rounded-lg.text-white > svg.MuiSvgIcon-root.MuiSvgIcon-fontSizeMedium.css-vubbuv</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html/body/div/div/div/div[2]/div/div/div/div/div/div[2]/div[2]/div/div/div/div[1]/div[4]/div/button[1]</value>
      <webElementGuid>c3a8fe74-d54a-4ad3-b90d-812c34bf9f6a</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Technology is a technology best'])[1]/following::*[name()='svg'][1]</value>
      <webElementGuid>2dcfc009-cb2c-47e9-a32a-b0f972a46996</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Technology'])[1]/following::*[name()='svg'][1]</value>
      <webElementGuid>450c4540-1057-4b43-962c-59fdd06048d0</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Anime'])[1]/preceding::*[name()='svg'][2]</value>
      <webElementGuid>bd82cf90-9eec-4550-ac0a-9eb43c3daba0</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Anime is my favorite show'])[1]/preceding::*[name()='svg'][2]</value>
      <webElementGuid>698919b6-b0d4-4910-a1a0-48ea25b9e919</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
