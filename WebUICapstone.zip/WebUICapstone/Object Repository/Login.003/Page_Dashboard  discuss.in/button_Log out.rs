<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>button_Log out</name>
   <tag></tag>
   <elementGuidId>0e09c9ad-50b1-4057-b0c2-dc2aafa30cc5</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value></value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='root']/div/div/div/div[2]/div/button</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>button</value>
      <webElementGuid>c7d69c41-f04a-4572-91bd-52f6691887c5</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>flex gap-2 text-[16px] text-white py-2 px-4 mr-4</value>
      <webElementGuid>d11cce74-10b2-43a7-8fc0-a1aa1d8939cd</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Log out</value>
      <webElementGuid>9725ec95-aa2b-4b43-8e6f-3042d4666b5f</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;root&quot;)/div[@class=&quot;App&quot;]/div[@class=&quot;flex w-full&quot;]/div[@class=&quot;h-screen w-[224px] shadow-2xl bg-navy pt-4&quot;]/div[@class=&quot;flex flex-col justify-between items-center h-[85vh]&quot;]/div[@class=&quot;bg-danger rounded-[10px]&quot;]/button[@class=&quot;flex gap-2 text-[16px] text-white py-2 px-4 mr-4&quot;]</value>
      <webElementGuid>64243b9b-b4d9-4882-8133-ec2091640d3f</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='root']/div/div/div/div[2]/div/button</value>
      <webElementGuid>d895775d-67fa-4215-939c-72dba2a64fa3</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Topic'])[1]/following::button[1]</value>
      <webElementGuid>64400307-8f06-4f19-8ca5-c00a0bb83d97</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Threads'])[1]/following::button[1]</value>
      <webElementGuid>9b23e567-224f-4c24-872a-9effb5062d44</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Dashboard'])[2]/preceding::button[1]</value>
      <webElementGuid>dd3a12af-d4d3-4945-ba66-adb6b3cf715e</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Users'])[2]/preceding::button[1]</value>
      <webElementGuid>003e2e44-142c-4d62-8440-18dbb8b92d98</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Log out']/parent::*</value>
      <webElementGuid>069d17d7-d2dd-48c2-b099-adb1bb7941ed</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//button</value>
      <webElementGuid>2e27c14f-ae88-4bb3-964d-db6cb1f2803b</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//button[(text() = 'Log out' or . = 'Log out')]</value>
      <webElementGuid>0932097c-47c9-40e0-b9db-7c0ab11dcdc3</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
