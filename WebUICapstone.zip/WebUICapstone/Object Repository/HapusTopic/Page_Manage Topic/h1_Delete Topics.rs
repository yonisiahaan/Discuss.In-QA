<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>h1_Delete Topics</name>
   <tag></tag>
   <elementGuidId>35f792ef-e97c-4994-ae93-f90e53dfc61b</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>h1.px-5.font-extrabold</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>(.//*[normalize-space(text()) and normalize-space(.)='Sebauah usaha tidak pernah menghianati hasil'])[1]/following::h1[1]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>h1</value>
      <webElementGuid>207a877b-354b-42d2-b3be-669d809d07b0</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>px-5 font-extrabold</value>
      <webElementGuid>126b5dee-74a2-4a4f-b348-02fff271fec0</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Delete Topics</value>
      <webElementGuid>1e2061f1-43f7-460d-80a7-03930cda6c1e</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[1]/body[1]/div[@class=&quot;flex items-center justify-center MuiModal-root css-8ndowl&quot;]/div[@class=&quot;bg-white w-[30vw] flex flex-col gap-3 pt-5 rounded-lg text-center items-center MuiBox-root css-0&quot;]/h1[@class=&quot;px-5 font-extrabold&quot;]</value>
      <webElementGuid>3960d6bd-0466-47c6-a303-4fa7c5219e29</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Sebauah usaha tidak pernah menghianati hasil'])[1]/following::h1[1]</value>
      <webElementGuid>8ad6ddbe-671f-48b8-9855-4b6b697725e9</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Motivasi'])[1]/following::h1[1]</value>
      <webElementGuid>6eaee851-3ec5-450a-8bb9-3abb4f5baa08</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='No'])[1]/preceding::h1[1]</value>
      <webElementGuid>b757f7e5-cf07-41df-ae91-34596ee5144b</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Yes'])[1]/preceding::h1[1]</value>
      <webElementGuid>57b50b7a-e5fa-4ef9-bf75-7d19303e9a73</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Delete Topics']/parent::*</value>
      <webElementGuid>d8d20f2d-be21-4592-a37d-d921f9a7fcef</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[3]/h1</value>
      <webElementGuid>0396ac8e-d369-4b73-9d71-f00c5ceed21b</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//h1[(text() = 'Delete Topics' or . = 'Delete Topics')]</value>
      <webElementGuid>e1550272-e1d9-457d-a62c-2c781fc3a0ab</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
