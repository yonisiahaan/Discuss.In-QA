<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>svg_Users_MuiSvgIcon-root MuiSvgIcon-fontSi_d1a833</name>
   <tag></tag>
   <elementGuidId>1c617520-5bbd-474b-af91-3d6b345a1a22</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>/html/body/div/div/div/div[2]/div/div/div/div/div[2]/div[2]/div/div/div/div[1]/div[5]/div/div[2]</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>(.//*[normalize-space(text()) and normalize-space(.)='Users'])[1]/following::*[name()='svg'][1]</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value></value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html/body/div/div/div/div[2]/div/div/div/div/div[2]/div[2]/div/div/div/div[1]/div[5]/div/div[2]</value>
      <webElementGuid>1106f840-6f6e-4813-9cf5-4fd1e84f6bb9</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Users'])[1]/following::*[name()='svg'][1]</value>
      <webElementGuid>231e2e34-85f4-4c41-93fc-c6418b28f29c</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Dashboard'])[1]/following::*[name()='svg'][2]</value>
      <webElementGuid>6ce545fc-0659-414b-afb3-0611a1f99d12</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Post'])[1]/preceding::*[name()='svg'][1]</value>
      <webElementGuid>8bcc048b-ae19-4e0c-beea-76619654d158</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Topic'])[1]/preceding::*[name()='svg'][2]</value>
      <webElementGuid>6e9b6057-91ad-4bc6-aa85-1337b153b5eb</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
