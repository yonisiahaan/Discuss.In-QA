<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>svg_Users_MuiSvgIcon-root MuiSvgIcon-fontSi_d1a833</name>
   <tag></tag>
   <elementGuidId>1607b4f3-4bcd-4241-b660-949062bedaa6</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>(.//*[normalize-space(text()) and normalize-space(.)='Users'])[1]/following::*[name()='svg'][1]</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value></value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>svg</value>
      <webElementGuid>9dbaf550-98fa-4882-bbbf-ccb9f4354d71</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>MuiSvgIcon-root MuiSvgIcon-fontSizeMedium css-vubbuv</value>
      <webElementGuid>f4c0d7b6-d09a-4b02-9a31-c0dc1d162b60</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>focusable</name>
      <type>Main</type>
      <value>false</value>
      <webElementGuid>10942d9a-7ea1-47a4-904a-543fedfe77ec</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>aria-hidden</name>
      <type>Main</type>
      <value>true</value>
      <webElementGuid>e8609884-0872-470c-ab71-9e550dfa037d</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>viewBox</name>
      <type>Main</type>
      <value>0 0 24 24</value>
      <webElementGuid>af180347-d5d3-470b-8696-1783fe9714c5</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>data-testid</name>
      <type>Main</type>
      <value>ViewComfyOutlinedIcon</value>
      <webElementGuid>0a3424cc-dbba-4121-ab20-2b366374c09e</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;root&quot;)/div[@class=&quot;App&quot;]/div[@class=&quot;flex w-full&quot;]/div[@class=&quot;h-screen text-none w-[15vw] shadow-2xl bg-navy pt-4&quot;]/div[@class=&quot;flex flex-col justify-between items-center h-[85vh]&quot;]/ul[1]/li[3]/a[@class=&quot;flex gap-2 items-center my-5 p-2 text-[16px] rounded-[10px] text-white false&quot;]/svg[@class=&quot;MuiSvgIcon-root MuiSvgIcon-fontSizeMedium css-vubbuv&quot;]</value>
      <webElementGuid>1727b434-23cc-4eb6-bb93-b5f541b62a66</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Users'])[1]/following::*[name()='svg'][1]</value>
      <webElementGuid>ae834ad2-a240-4f59-8ca3-29f98c88f255</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Dashboard'])[1]/following::*[name()='svg'][2]</value>
      <webElementGuid>4382b774-949d-4b3e-89d6-f2eb9f5b7b33</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Post'])[1]/preceding::*[name()='svg'][1]</value>
      <webElementGuid>74f26961-2066-4b91-8cd8-7d5579e6b474</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Topic'])[1]/preceding::*[name()='svg'][2]</value>
      <webElementGuid>b9ce47f9-bedb-417a-adea-d7fbc6f1a1e1</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
