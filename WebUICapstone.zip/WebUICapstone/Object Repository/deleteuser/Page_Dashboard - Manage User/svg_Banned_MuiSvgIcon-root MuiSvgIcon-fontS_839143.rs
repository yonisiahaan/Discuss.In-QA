<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>svg_Banned_MuiSvgIcon-root MuiSvgIcon-fontS_839143</name>
   <tag></tag>
   <elementGuidId>ee3d637a-e25a-49ff-b1c0-0ca67235a5d5</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>/html/body/div/div/div/div[2]/div/div/div/div/div[2]/div[2]/div/div/div/div[1]/div[4]/div/button[2]</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>(.//*[normalize-space(text()) and normalize-space(.)='Banned'])[1]/following::*[name()='svg'][1]</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>button.bg-danger.p-2.rounded-lg.text-white > svg.MuiSvgIcon-root.MuiSvgIcon-fontSizeMedium.css-vubbuv</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html/body/div/div/div/div[2]/div/div/div/div/div[2]/div[2]/div/div/div/div[1]/div[4]/div/button[2]</value>
      <webElementGuid>80794539-a80c-4173-8ec8-f25cc4633397</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Banned'])[1]/following::*[name()='svg'][1]</value>
      <webElementGuid>2c35cad2-2231-498a-abc7-99836eb4e2a7</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='ademrizki@gmail.com'])[1]/following::*[name()='svg'][1]</value>
      <webElementGuid>24617804-4413-4cd8-8681-36795adfd071</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='bsnh25'])[1]/preceding::*[name()='svg'][1]</value>
      <webElementGuid>c238e123-37d8-447f-921b-bcb79b65e5e6</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='hemkodok@gmail.com'])[1]/preceding::*[name()='svg'][1]</value>
      <webElementGuid>66bf2b5c-b037-44e8-9d78-88867944ab5a</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
